# Spark Chat

**Simple. Fast. Connected.**

A buildable Android Studio starter project for the Spark Chat concept.

## Included demo screens
- Registration screen
- Chats
- Status / Updates
- Channels
- Communities
- Calls
- Settings
- Owner/Admin placeholder
- Original Spark Chat branding

## Build
1. Open this folder in Android Studio.
2. Allow Gradle to sync and install any requested Android SDK components.
3. Run the app on an emulator or connected Android phone.
4. For an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important
This project is a local UI/demo foundation. Production features such as real SMS verification, real-time messaging, accounts, end-to-end encryption, push notifications, voice/video calling, cloud storage, searchable licensed music, subscriptions and an owner backend require a secure backend and third-party services. Do not put secret API keys in the Android app.

## Build from a phone (GitHub Actions)
1. Upload this project to a GitHub repository.
2. Open the Actions tab and run **Build Spark Chat APK**.
3. After it finishes, open the workflow run and download the **SparkChat-debug-apk** artifact.
