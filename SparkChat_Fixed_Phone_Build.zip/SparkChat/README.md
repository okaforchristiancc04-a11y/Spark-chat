# Spark Chat

**Simple. Fast. Connected.**

This is a buildable Android Studio starter project for the Spark Chat concept.

## Included demo screens
- Registration screen
- Chats
- Status / Updates
- Channels
- Communities
- Calls
- Settings
- Owner/Admin placeholder
- Spark Chat branding

## Build with GitHub Actions from a phone
1. Upload the contents of this `SparkChat` folder to the root of your GitHub repository.
2. Make sure `.github/workflows/build-apk.yml` is also uploaded.
3. Open the repository's **Actions** tab.
4. Choose **Build Spark Chat APK**.
5. Tap **Run workflow**.
6. When it finishes successfully, open the run and download the `SparkChat-debug-apk` artifact.

## Build locally
Open the `SparkChat` folder in Android Studio and build the APK.

## Important
This project is a local UI/demo foundation. Production features such as real SMS verification, real-time messaging, accounts, end-to-end encryption, push notifications, voice/video calling, cloud storage, searchable licensed music, subscriptions and an owner backend require secure backend services. Do not put secret API keys in the Android app.
